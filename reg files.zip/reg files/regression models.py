import numpy as np
import pandas as pd
import seaborn as sns
import pickle
import matplotlib.pyplot as plt
from sklearn import metrics
import re
from sklearn.feature_selection import SelectKBest,  chi2
from sklearn.datasets import load_digits
from sklearn.linear_model import LinearRegression , Lasso , Ridge
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import RANSACRegressor
from xgboost import XGBRegressor
from sklearn.linear_model import HuberRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import time
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from textblob import TextBlob
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import load_iris
import warnings
warnings.filterwarnings("ignore")

da = pd.read_csv("hotel-regression-dataset.csv")
print(da.head())

# drop not useful data and missing values
da.dropna(how='any', inplace=True)
da.drop_duplicates(inplace=True)
da.drop(['lat', 'lng'], axis=1)

# 1- preprocessing
da['Review_Date'] = pd.to_datetime(da['Review_Date'])
da['Review_Date'] = np.array(da['Review_Date'].dt.strftime("%m%d%Y"))

print(da.describe())

# Handle outliers
q1 = da['Average_Score'].quantile(0.25)
q3 = da['Average_Score'].quantile(0.75)
iqr = q3 - q1
L_b = q1 - 1.5*iqr
U_b = q3 + 1.5*iqr
da = da[(da['Average_Score'] >= L_b) & (da['Average_Score'] <= U_b)]

X = da.iloc[:, :-1]
Y = da['Reviewer_Score']
print("x.shape is : {}".format(X.shape))
print("y.shape is : {}".format(Y.shape))

def Feature_Encoder(X , cols):
    for c in cols:
        lbl = LabelEncoder()
        lbl.fit(list(X[c].values))
        X[c] = lbl.transform(list(X[c].values))
    return X
cols = ('Hotel_Address', 'Hotel_Name' , 'Reviewer_Nationality' , 'Negative_Review' , 'Positive_Review' , 'Tags' , 'days_since_review')
X = Feature_Encoder(da, cols=cols)

#Get the correlation between the features
hotel_data = da.iloc[:, :]
corr = hotel_data.corr()
sns.heatmap(corr, annot=True)
plt.title("Correlation Matrix")
plt.show()

top_feature = corr.index[abs(corr['Reviewer_Score']) > 0.2]
top_feature = top_feature.delete(-1)
X = X[top_feature]

print(da['Hotel_Name'].value_counts())
print(da['Reviewer_Nationality'].value_counts())

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, train_size=0.8, shuffle=True, random_state=42)

# feature selection
X, Y = load_digits(return_X_y=True)
X = SelectKBest(chi2, k='all').fit_transform(X, Y)

# feature scaling(Normalization)
from sklearn.preprocessing import MinMaxScaler
mm = MinMaxScaler(feature_range=(0, 1))
X_train = mm.fit_transform(X_train)
X_test = mm.transform(X_test)

# 2- Regression Techniques
arr = ['Additional_Number_of_Scoring', 'Average_Score', 'Review_Total_Negative_Word_Counts', 'Total_Number_of_Reviews',
       'Review_Total_Positive_Word_Counts', 'Total_Number_of_Reviews_Reviewer_Has_Given']
def reg_model(model):
    model.fit(X_train , y_train)
    model_name = str(type(model)).split('.')[-1][:-2]
    model_name = re.sub(r'\([^)]*\)', '', model_name)
    print("Train Error({}) = {} {}Test Error({}) = {}".format(model_name,
            metrics.mean_squared_error(y_train, model.predict(X_train)), ' , ', model_name,
            metrics.mean_squared_error(y_test, model.predict(X_test))))
    print("Train r2_score({}) = {} ".format(model_name, metrics.r2_score(y_train, model.predict(X_train))), ' , ',
          "Test r2_score({}) = {} ".format(model_name, metrics.r2_score(y_test, model.predict(X_test))))

lr = reg_model(LinearRegression())
lasso_r = reg_model(Lasso())
ridge_reg = reg_model(Ridge())
tree_reg = reg_model(DecisionTreeRegressor())
random_forest_reg = reg_model(RandomForestRegressor(n_estimators = 100, max_depth=9 , random_state=42))
ransac = reg_model(RANSACRegressor())
huber = reg_model(HuberRegressor())
sgb = reg_model(XGBRegressor())
svr = reg_model(SVR(kernel = 'rbf'))
print(lr, '\n', lasso_r, '\n', ridge_reg, '\n', tree_reg, '\n', random_forest_reg, '\n',
      ransac, '\n', huber, '\n', sgb, '\n', svr)
# ============= Model 1-simple linear regression =============
for var in arr:
    plt.figure()
    sns.regplot(x=var, y='Reviewer_Score', data=da, scatter_kws={"color":"black", "alpha":0.5} , line_kws= {"color":"red"})
    plt.title(f'Regression line of {var} and Reviewer_Score')
    plt.show()

# ============== Model 2-polynomial regression=============
print("============Model 2- polynomial regression=============")
T_errors = []
test_errors = []
l_deg = range(1, 10)
for deg in l_deg:
    poly_features = PolynomialFeatures(degree=deg)
    X_train_poly = poly_features.fit_transform(X_train)

    poly_model = LinearRegression()
    poly_model.fit(X_train_poly, y_train)
    y_train_predicted = poly_model.predict(X_train_poly)
    ypred = poly_model.predict(poly_features.transform(X_test))

    print('Mean Square Error of Test of degree ', deg, " is : ", metrics.mean_squared_error(y_test, poly_model.predict(poly_features.fit_transform(X_test))) ,
          ', Mean Square Error of Train of degree ', deg, " is : ", metrics.mean_squared_error(y_train, poly_model.predict(poly_features.fit_transform(X_train))))
    print('r2_Score of Test of degree ', deg, " is : ", metrics.r2_score(y_test, poly_model.predict(poly_features.fit_transform(X_test))) ,
          ', r2_Score of Train of degree ', deg, " is : ", metrics.r2_score(y_train, poly_model.predict(poly_features.fit_transform(X_train))))

    T_errors.append(metrics.mean_squared_error(y_train, poly_model.predict(poly_features.fit_transform(X_train))))
    test_errors.append(metrics.mean_squared_error(y_test, poly_model.predict(poly_features.fit_transform(X_test))))

plt.plot(l_deg, T_errors, label='Train')
plt.plot(l_deg, test_errors, label='Test')
plt.xlabel('Polynomial Degree')
plt.ylabel('Mean Squared Error')
plt.title('Train and Test Errors vs Polynomial Degree')
plt.legend()
plt.show()

# ==============================BONUS==============================
print("==============================BONUS===============================")

#da['equal_or_lower_than_5?'] = da['Reviewer_Score'].apply(lambda w: 'Low_or_Intermediate_Score' if w <= 5 else 'High_Score')

# method 1 for sentiment analysis
# clean the text data
stop_words = set(stopwords.words('english'))
def clean_text(text):
    text = text.lower()
    words = word_tokenize(text)
    words = [w for w in words if w not in stop_words or w == 'No' or w == 'no']
    text = " ".join(words)
    return text

da['Negative_Review'] = clean_text(da['Negative_Review'].to_string().encode())
print(da['Negative_Review'])
print("==================================================================")
da['Positive_Review'] = clean_text(da['Positive_Review'].to_string().encode())
print(da['Positive_Review'])

# method 2 for sentiment analysis
print("==================================================================")

def get_sentiment(text):
    blob = TextBlob(text)
    if blob.sentiment.polarity > 0:
        return 'Positive'
    elif blob.sentiment.polarity < 0:
        return 'Negative'
    else:
        return 'Neutral'
da['negative_sentiment'] = da['Negative_Review'].apply(get_sentiment)
print(da['negative_sentiment'])
print("==================================================================")
da['positive_sentiment'] = da['Positive_Review'].apply(get_sentiment)
print(da['positive_sentiment'])

# Method 3
from wordcloud import WordCloud

def wordcloud_plot(da, title = None):
    wordcloud = WordCloud(
        background_color='black',
        max_words=250,
        max_font_size=50,
        scale=5,
        random_state=5
    ).generate(str(da))

    fig = plt.figure(1, figsize=(10, 20))
    plt.axis('off')
    if title:
        fig.suptitle(title, fontsize=12)
        fig.subplots_adjust(top=2.3)

    plt.imshow(wordcloud)
    plt.show()
print(wordcloud_plot(da['Negative_Review']))
print(wordcloud_plot(da['Positive_Review']))

# print time training
print("==================================================================")
model = MLPClassifier()
X_train, y_train = load_iris(return_X_y=True)
start = time.time()
model.fit(X_train, y_train)
stop = time.time()
print(f"Training time: {round(stop - start , 2)}s")

print("==================================================================")
# print total time
start = time.time()
# sleeping for 1 sec to get 10 sec runtime
time.sleep(1)
end = time.time()

# total time taken
print(f"Runtime of the program is {round(end - start , 2)}s")
print("==================================================================")

# Save data
da.to_csv("Updated_data_hotel.csv", index=False)
# end of milestone 1

# TEST SCRIPT
regmodel_name = 'linear.pickle'
feature_encoder_name = 'encoding.pickle'

pickle.dump(lr, open(regmodel_name, 'wb'))
pickle.dump(Feature_Encoder, open(feature_encoder_name, 'wb'))

# Load the saved model from disk
loaded_model = pickle.load(open(regmodel_name, 'rb'))
loaded_encoder_model = pickle.load(open(feature_encoder_name, 'rb'))

new_data = ...

predictions = loaded_model.predict()
print("predictions: ", predictions)
